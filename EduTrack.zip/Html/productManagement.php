<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Document</title>

    <link rel="stylesheet" href="../Css/systemNav.css" />
    <link rel="stylesheet" href="../Css/productManagement.css" /> 

    <link
      href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap"
      rel="stylesheet"
    />


</head>
<body>
  <div class="systemNav-container">

    <?php include("systemNav.php"); ?>
      <div class="container">
        <h2>Product Management</h2>
        <div class="buttons">
            <button onclick="openModal()" class="add-btn">Add Product</button>
        </div>

        <!-- MODAL -->
        <div id="productModal" class="modal">
          <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>

            <h3>Product Form</h3>

            <input type="text" id="name" placeholder="Product ID">
            <input type="text" id="type" placeholder="Product Type">

            <select id="size">
                <option value="">Size</option>
                <option>Small</option>
                <option>Medium</option>
                <option>Large</option>
            </select>

            <select id="dept">
                <option value="">Department</option>
                <option>CICT</option>
                <option>CBEA</option>
                <option>CAFA</option>
                <option>CAL</option>
                <option>COE</option>
                <option>COED</option>
                <option>CS</option>
                <option>CIT</option>
                <option>CHTM</option>
                <option>CSER</option>
                <option>CSSP</option>
                <option>CCJE</option>
                <option>CLaw</option>
                <option>CN</option>
            </select>

            <input type="text" id="price" placeholder="Price">

            <div class="buttons">
                <button onclick="saveProduct()" class="add-btn">Save</button>
            </div>
          </div>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Product ID</th>
                    <th>Type</th>
                    <th>Size</th>
                    <th>Dept</th>
                    <th>Price</th>
                    <th></th> 
                </tr>
            </thead>
            <tbody id="table"></tbody>
        </table>
        </div>
      </div>


  </div>
    <script src="https://unpkg.com/lucide@latest"></script>

      <script src="../Script/systemNav.js"></script>
      <script src="../Script/productManagement.js"></script>
</body>
</html>