// let rowIndex = null;

// function addProduct() {
//   let name = document.getElementById("name").value;
//   let type = document.getElementById("type").value;
//   let size = document.getElementById("size").value;
//   let dept = document.getElementById("dept").value;
//   let qty = document.getElementById("qty").value;
//   let price = document.getElementById("price").value;

//   if (
//     name === "" ||
//     type === "" ||
//     size === "" ||
//     dept === "" ||
//     qty === "" ||
//     price === ""
//   ) {
//     alert("Please fill in all fields!");
//     return;
//   }

//   let table = document.getElementById("table");
//   let row = table.insertRow();

//   row.insertCell(0).innerHTML = name;
//   row.insertCell(1).innerHTML = type;
//   row.insertCell(2).innerHTML = size;
//   row.insertCell(3).innerHTML = dept;
//   row.insertCell(4).innerHTML = qty;
//   row.insertCell(5).innerHTML = price;

//   row.insertCell(6).innerHTML =
//     '<button class="edit-btn" onclick="editRow(this)">Edit</button>' +
//     '<button class="delete-btn" onclick="deleteRow(this)">Delete</button>';

//   clearForm();
// }

// function editRow(btn) {
//   let row = btn.parentElement.parentElement;
//   rowIndex = row;

//   document.getElementById("name").value = row.cells[0].innerHTML;
//   document.getElementById("type").value = row.cells[1].innerHTML;
//   document.getElementById("size").value = row.cells[2].innerHTML;
//   document.getElementById("dept").value = row.cells[3].innerHTML;
//   document.getElementById("qty").value = row.cells[4].innerHTML;
//   document.getElementById("price").value = row.cells[5].innerHTML;
// }

// function updateProduct() {
//   if (rowIndex === null) {
//     alert("Select a row first!");
//     return;
//   }

//   let name = document.getElementById("name").value;
//   let type = document.getElementById("type").value;
//   let size = document.getElementById("size").value;
//   let dept = document.getElementById("dept").value;
//   let qty = document.getElementById("qty").value;
//   let price = document.getElementById("price").value;

//   if (
//     name === "" ||
//     type === "" ||
//     size === "" ||
//     dept === "" ||
//     qty === "" ||
//     price === ""
//   ) {
//     alert("Please fill in all fields!");
//     return;
//   }

//   rowIndex.cells[0].innerHTML = name;
//   rowIndex.cells[1].innerHTML = type;
//   rowIndex.cells[2].innerHTML = size;
//   rowIndex.cells[3].innerHTML = dept;
//   rowIndex.cells[4].innerHTML = qty;
//   rowIndex.cells[5].innerHTML = price;

//   rowIndex = null;
//   clearForm();
// }

// function deleteRow(btn) {
//   if (confirm("Are you sure you want to delete this product?")) {
//     let row = btn.parentElement.parentElement;
//     row.remove();

//     rowIndex = null;
//     clearForm();
//   }
// }

// function clearForm() {
//   document.getElementById("name").value = "";
//   document.getElementById("type").value = "";
//   document.getElementById("size").value = "";
//   document.getElementById("dept").value = "";
//   document.getElementById("qty").value = "";
//   document.getElementById("price").value = "";
// }

let rowIndex = null;

function openModal() {
  document.getElementById("productModal").style.display = "block";
}

function closeModal() {
  document.getElementById("productModal").style.display = "none";
  clearForm();
  rowIndex = null;
}

function saveProduct() {
  let name = document.getElementById("name").value;
  let type = document.getElementById("type").value;
  let size = document.getElementById("size").value;
  let dept = document.getElementById("dept").value;
  let price = document.getElementById("price").value;

  if (
    name === "" ||
    type === "" ||
    size === "" ||
    dept === "" ||
    price === ""
  ) {
    alert("Please fill in all fields!");
    return;
  }

  if (rowIndex === null) {
    // ADD
    let table = document.getElementById("table");
    let row = table.insertRow();

    row.insertCell(0).innerHTML = name;
    row.insertCell(1).innerHTML = type;
    row.insertCell(2).innerHTML = size;
    row.insertCell(3).innerHTML = dept;
    row.insertCell(4).innerHTML = price;

    row.insertCell(5).innerHTML =
      '<button class="edit-btn" onclick="editRow(this)">Edit</button>' +
      '<button class="delete-btn" onclick="deleteRow(this)">Delete</button>';
  } else {
    // UPDATE (via Edit)
    rowIndex.cells[0].innerHTML = name;
    rowIndex.cells[1].innerHTML = type;
    rowIndex.cells[2].innerHTML = size;
    rowIndex.cells[3].innerHTML = dept;
    rowIndex.cells[4].innerHTML = price;
  }

  closeModal();
}

function editRow(btn) {
  let row = btn.parentElement.parentElement;
  rowIndex = row;

  openModal();

  document.getElementById("name").value = row.cells[0].innerHTML;
  document.getElementById("type").value = row.cells[1].innerHTML;
  document.getElementById("size").value = row.cells[2].innerHTML;
  document.getElementById("dept").value = row.cells[3].innerHTML;
  document.getElementById("price").value = row.cells[4].innerHTML;
}

function deleteRow(btn) {
  if (confirm("Are you sure you want to delete this product?")) {
    let row = btn.parentElement.parentElement;
    row.remove();
    rowIndex = null;
  }
}

function clearForm() {
  document.getElementById("name").value = "";
  document.getElementById("type").value = "";
  document.getElementById("size").value = "";
  document.getElementById("dept").value = "";
  document.getElementById("price").value = "";
}
